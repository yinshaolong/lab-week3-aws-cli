
.. _constrain.ContainedSubtypeConstraint:

.. |Constraint| replace:: ContainedSubtypeConstraint

Contained subtype constraint
----------------------------

.. autoclass:: pyasn1.type.constraint.ContainedSubtypeConstraint
   :members:
